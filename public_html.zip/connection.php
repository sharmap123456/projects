<!-- database connection file -->
<?php
$host = "localhost";
$username = "u764328548_priya";
$password = "Priya@sharma0000";
$database = "u764328548_priya";   //enter your database name 

$con = mysqli_connect($host, $username, $password, $database);

if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
?>