
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact</title>
    <link rel="stylesheet" href="boxicons-2.1.2/css/boxicons.css">
    <link rel="stylesheet" href="boxicons-2.1.2/css/style.css">
    <link rel="shortcut icon" href="./favicon.svg" type="image/x-icon">


</head>
<header class="header" data-header>
    <div class="container">
        <div class="overlay" data-overlay></div>

        <a href="index.php" class="logo">
            <img src="img/Fitbit-removebg-preview.png" width="auto" height="150" alt="Footcap Logo">
        </a>

        <button class="nav-open-btn" data-nav-open-btn aria-label="Open Menu">
            <i class="bx bx-menu"></i>
        </button>

        <nav class="navbar" data-navbar>
            <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
                <i class="bx bx-x"></i>
            </button>

            <a href="" class="logo">
                <img src="img/Fitbit-removebg-preview.png" width="190" height="250" alt="Fitbit Logo">
            </a>

            <ul class="navbar-list">
                <li class="navbar-item">
                    <a href="index.php" class="navbar-link">Home</a>
                </li>
                <li class="navbar-item">
                    <a href="collection.php" class="navbar-link">Collection</a>
                </li>
                <li class="navbar-item">
                    <a href="product.php" class="navbar-link">Products</a>
                </li>
                <li class="navbar-item">
                    <a href="shop.php" class="navbar-link">Shop</a>
                </li>
                
                <li class="navbar-item">
                    <a href="contact.php" class="navbar-link">Contact</a>
                </li>
            </ul>

            <ul class="nav-action-list">
               

                <li>
                    <a href="login.php" class="nav-action-btn">
                    <p class="navbar-link"> My Account</p>
                        <i class="bx bx-user" aria-hidden="true"></i>

                        <span class="nav-action-text">Login / Register</span>
                    </a>
                </li>

                

              
            </ul>
        </nav>
    </div>
</header>
<body>
    <footer class="footer">
        <div class="footer-top section" style="align-items: center;">
            <div class="container">
                <div class="footer-brand">
                    <div class="footer-link-box">
                        <ul class="footer-list">
                            <li>
                                <p class="footer-list-title">Contact Us</p>
                            </li>
                
                            <li>
                                <address class="footer-link">
                                    <i class="bx bxs-map"></i>
                
                                    <a href="https://www.google.com/maps/place/Shoe+Hut/@30.8883254,75.8222251,15z/data=!4m10!1m2!2m1!1sfitbit+shoe+store+ludhiana!3m6!1s0x391a824d301535cb:0xd3a2b760fba6a5f8!8m2!3d30.8883254!4d75.8402495!15sChpmaXRiaXQgc2hvZSBzdG9yZSBsdWRoaWFuYVocIhpmaXRiaXQgc2hvZSBzdG9yZSBsdWRoaWFuYZIBCnNob2Vfc3RvcmXgAQA!16s%2Fg%2F11b6q02ht8?entry=ttu"<span class="footer-link-text">
                                        
                                         B-18, 424/1C, 425/1, near Gulati Chowk                                </span>  </a>  
                                </address>
                            </li>
                
                            <li>
                                <a href="tel:7123489071" class="footer-link">
                                    <i class="bx bxs-phone"></i>
                
                                    <span class="footer-link-text">7123489071</span>
                                </a>
                            </li>
                
                            <li>
                                <a href="mailto:fitbit.com" class="footer-link">
                                    <i class="bx bxs-envelope"></i>
                
                                    <span class="footer-link-text">fitbit@help.com</span>
                                </a>
                            </li>
                            
                        </ul>
                
                        <ul class="footer-list">
                            <li>
                                <p class="footer-list-title">My Account</p>
                            </li>
                
                            <li>
                                <a href="https://myaccount.google.com/?utm_source=OGB&utm_medium=app&pli=1" class="footer-link">
                                    <i class="bx bx-chevron-right"></i>
                
                                    <span class="footer-link-text">Home</span>
                                </a>
                            </li>
                
                            <li>
                                <a href="hh.php" class="footer-link">
                                    <i class="bx bx-chevron-right"></i>
                
                                    <span class="footer-link-text">View Cart</span>
                                </a>
                            </li>
                            <li>
                                    <a href="login.php" class="footer-link">
                                        <i class="bx bx-chevron-right"></i>
                                        <span class="footer-link-text">login</span>
</a>
</li>

                           
                
                            <li>
                                <a href="product.php" class="footer-link">
                                    <i class="bx bx-chevron-right"></i>
                
                                    <span class="footer-link-text">New Products</span>
                                </a>
                            </li>
                
            </div>
        </ul>
        <ul class="footer-list">
            <li>
               <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27390.00724285767!2d75.78803021083985!3d30.893628599999992!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391a83c954d14261%3A0xecc3cded35f1cdaa!2sHelios%20Watch%20Store%20-%20By%20Titan!5e0!3m2!1sen!2sin!4v1713598941608!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </li>
        </ul>
</div>
</div>
</div>
</div>

<div class="footer-buttom">
<div class="container">
    <p class="copyright">
        &copy; 2024 <a href="#" class="copyright-link">Fitbit</a>.Made by Tanupriya
    </p>
</div>
</div>
</footer>

<!--GO TO TOP-->
<a href="#top" class="go-top-btn" data-go-top>
<i class="bx bx-up-arrow-alt"></i>
</a>

</article>
</main>

<script src="main.js"></script>
<!--ionicon link-->
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>



</body>

</html>