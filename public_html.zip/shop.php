<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <link rel="stylesheet" href="boxicons-2.1.2/css/boxicons.css">
    <link rel="stylesheet" href="boxicons-2.1.2/css/style.css">
    <link rel="shortcut icon" href="./favicon.svg" type="image/x-icon">


</head>
<header class="header" data-header>
    <div class="container">
        <div class="overlay" data-overlay></div>

        <a href="index.php" class="logo">
            <img src="img/Fitbit-removebg-preview.png" width="auto" height="150" alt="Footcap Logo">
        </a>

        <button class="nav-open-btn" data-nav-open-btn aria-label="Open Menu">
            <i class="bx bx-menu"></i>
        </button>

        <nav class="navbar" data-navbar>
            <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
                <i class="bx bx-x"></i>
            </button>

            <a href="" class="logo">
                <img src="img/Fitbit-removebg-preview.png" width="190" height="250" alt="Fitbit Logo">
            </a>

            <ul class="navbar-list">
                <li class="navbar-item">
                    <a href="index.php" class="navbar-link">Home</a>
                </li>
                <li class="navbar-item">
                    <a href="collection.php" class="navbar-link">Collection</a>
                </li>
                <li class="navbar-item">
                    <a href="product.php" class="navbar-link">Products</a>
                </li>
                <li class="navbar-item">
                    <a href="shop.php" class="navbar-link">Shop</a>
                </li>
               
                <li class="navbar-item">
                    <a href="contact.php" class="navbar-link">Contact</a>
                </li>
            </ul>

            <ul class="nav-action-list">
                <li>
                    <a href="login.php" class="nav-action-btn">
                    <p class="navbar-link"> My Account</p>
                        <i class="bx bx-user" aria-hidden="true"></i>

                        <span class="nav-action-text">Login / Register</span>
                    </a>
                </li>


            </ul>
        </nav>
    </div>
</header>

<body>
    <!--SPECIAL-->
    <section class="section special">
        <div class="container">
            <div class="special-banner" style="background-image: url('./img/special-banner.jpg');">
                <h2 class="h3 banner-title">New Trend Edition</h2>

                <a href="product.php" class="btn btn-link">
                    <span>Explore All</span>
                    <i class="bx bx-right-arrow-alt" aria-hidden="true"></i>
                </a>
            </div>


            <div class="special-product">
                <h2 class="h2 section-title">
                    <span class="title">Nike Special</span>

                    <span class="line"></span>
                </h2>

                <ul class="has-scrollbar">
                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-1.jpg" width="312" height="350" loading="lazy"
                                    alt="Running Sneaker Shoes" class="image-contain">

                                <div class="card-badge">New</div>
                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart-alt"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                   
                                </ul>
                            </figure>
                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Women</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Running Sneaker Shoes</a>
                                </h3>

                                <data class="card-price" value="980.85">₹980.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-2.jpg" width="312" height="350" loading="lazy"
                                    alt="Leather Mens Slipper" class="image-contain">

                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart-alt"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                   
                                </ul>
                            </figure>

                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Sports</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Leather Mens Slipper</a>
                                </h3>

                                <data class="card-price" value="1190.85">₹1190.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-3.jpg" width="312" height="350" loading="lazy"
                                    alt="Simple Fabric Shoe" class="image-contain">

                                <div class="card-badge">New</div>
                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart-alt"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                  
                                </ul>
                            </figure>
                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Women</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Simple Fabric Shoe</a>
                                </h3>

                                <data class="card-price" value="1060.85">₹1060.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-4.jpg" width="312" height="350" loading="lazy"
                                    alt="Air Jordan 7 Retro" class="image-contain">

                                <div class="card-badge">-25%</div>
                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart-alt"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                   
                                </ul>
                            </figure>
                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Sports</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Air Jordan 7 Retro</a>
                                </h3>

                                <data class="card-price" value="1170.85">₹1170.85 <del>₹1500.21</del></data>
                            </div>
                        </div>
                    </li>
                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-5.jpg" width="312" height="350" loading="lazy"
                                    alt="Nike Air Max 270 SE" class="image-contain">

                                <div class="card-badge">New</div>
                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                   

                                </ul>
                            </figure>

                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Women</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Nike Air Max 270 SE</a>
                                </h3>

                                <data class="card-price" value="1200.85">₹1200.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-6.jpg" width="312" height="350" loading="lazy"
                                    alt="Adidas Sneakers Shoes" class="image-contain">

                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                    


                                </ul>
                            </figure>

                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Women</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Adidas Sneakers Shoes</a>
                                </h3>

                                <data class="card-price" value="1080.85">₹1080.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-7.jpg" width="312" height="350" loading="lazy"
                                    alt="Nike Basketball shoes" class="image-contain">

                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>

                                  


                                </ul>
                            </figure>

                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Sports</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Nike Basketball shoes</a>
                                </h3>

                                <data class="card-price" value="1200.85">₹1200.85</data>
                            </div>
                        </div>
                    </li>

                    <li class="product-item">
                        <div class="product-card" tabindex="0">
                            <figure class="card-banner">
                                <img src="./img/product-8.jpg" width="312" height="350" loading="lazy"
                                    alt="Simple Fabric Shoe" class="image-contain">

                                <ul class="card-action-list">
                                    <li class="card-action-item">
                                        <button class="card-action-btn" aria-labelledby="card-label-1">
                                            <i class="bx bx-cart"></i>
                                        </button>

                                        <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                                    </li>


                                </ul>
                            </figure>

                            <div class="card-content">
                                <div class="card-cat">
                                    <a href="collection.php" class="card-cat-link">Men</a> /
                                    <a href="collection.php" class="card-cat-link">Women</a>
                                </div>

                                <h3 class="h3 card-title">
                                    <a href="product.php">Simple Fabric Shoe</a>
                                </h3>

                                <data class="card-price" value="1000.85">₹1000.85</data>
                            </div>
                        </div>
                    </li>

                </ul>
            </div>
        </div>
    </section>

    <!--SERVICE-->
    <section class="section service">
        <div class="container">
            <ul class="service-list">
                <li class="service-item">
                    <div class="service-card">
                        <div class="card-icon">
                            <img src="./img/service-1.png" width="53" height="28" loading="lazy" alt="Service icon">
                        </div>
                        <div>
                            <h3 class="h4 card-title">
                                Free Shiping
                            </h3>
                            <p class="card-text">
                                All orders over <span>₹1500</span>
                            </p>
                        </div>
                    </div>
                </li>

                <li class="service-item">
                    <div class="service-card">
                        <div class="card-icon">
                            <img src="./img/service-2.png" width="43" height="35" loading="lazy" alt="Service icon">
                        </div>
                        <div>
                            <h3 class="h4 card-title">
                                Quick Payment
                            </h3>
                            <p class="card-text">
                                100% secure payment
                            </p>
                        </div>
                    </div>
                </li>

                <li class="service-item">
                    <div class="service-card">
                        <div class="card-icon">
                            <img src="./img/service-3.png" width="40" height="40" loading="lazy" alt="Service icon">
                        </div>
                        <div>
                            <h3 class="h4 card-title">
                                Free Returns
                            </h3>
                            <p class="card-text">
                                Money back in 7 days
                            </p>
                        </div>
                    </div>
                </li>

                <li class="service-item">
                    <div class="service-card">
                        <div class="card-icon">
                            <img src="./img/service-4.png" width="43" height="35" loading="lazy" alt="Service icon">
                        </div>
                        <div>
                            <h3 class="h4 card-title">
                                24/7 Support
                            </h3>
                            <p class="card-text">
                                Get Quick Support
                            </p>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </section>

</body>

</html>