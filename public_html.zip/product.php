<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>product</title>
    <link rel="stylesheet" href="boxicons-2.1.2/css/boxicons.css">
    <link rel="shortcut icon" href="./favicon.svg" type="image/x-icon">

    <link rel="stylesheet" href="boxicons-2.1.2/css/style.css">
      <style>
        #cart {
        border: 1px solid  black;
        padding: 10px;
        background-color: white;
        position: fixed;
        top: 0;
        right: 0;
        z-index: 10;
      }
      
      /* Style for each cart item */
      .cart-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }
      
      .cart-item img {
        width: 30px; /* Adjust the size as needed */
        height: 40px; /* Adjust the size as needed */
        margin-right: 10px;
        /* visibility: visible !important; */
      }
      
      .cart-item span {
        margin-right: 10px;
      }
      .remove-btn {
                  padding: 5px 10px;
                  background-color: #ff6347; /* Red color */
                  color: #fff; /* White text color */
                  border: none;
                  border-radius: 4px;
                  cursor: pointer;
                  transition: background-color 0.3s ease;
              }
      
              .remove-btn:hover {
                  background-color: #d64533; /* Darker red color on hover */
              }
           
 </style>
    <title>hh</title>
</head>


<body>
 <header class="header" data-header>
        <div class="container">
            <div class="overlay" data-overlay></div>

            <a href="index.php" class="logo">
                <img src="img/Fitbit-removebg-preview.png" width="auto" height="150" alt="Fitbit Logo">
            </a>

            <button class="nav-open-btn" data-nav-open-btn aria-label="Open Menu">
                <i class="bx bx-menu"></i>
            </button>

            <nav class="navbar" data-navbar>
                <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
                    <i class="bx bx-x"></i>
                </button>

                <a href="" class="logo">
                    <img src="img/Fitbit-removebg-preview.png" width="190" height="250" alt="Fitbit Logo">
                </a>

                <ul class="navbar-list">
                    <li class="navbar-item">
                        <a href="index.php" class="navbar-link">Home</a>
                    </li>
                    <li class="navbar-item">
                        <a href="collection.php" class="navbar-link">Collection</a>
                    </li>
                    <li class="navbar-item">
                        <a href="product.php" class="navbar-link">Products</a>
                    </li>
                    <li class="navbar-item">
                        <a href="shop.php" class="navbar-link">Shop</a>
                    </li>
                    <li class="navbar-item">
                        <a href="contact.php" class="navbar-link">Contact</a>
                    </li>
                </ul>

                <ul class="nav-action-list">
                  

                    <li>
                        
                        <a href="login.php" class="nav-action-btn">
                            <p class="navbar-link"> My Account</p>
                            <i class="bx bx-user" aria-hidden="true"></i>

                            <span class="nav-action-text">Login / Register</span>
                        </a>
                    </li>

                  

                </ul>
            </nav>
        </div>
    </header>
      <div id="cart" style="display: inline-block;" >
    <ion-icon name="cart-sharp" style="width: 30px; height: 30px;"></ion-icon> 
    </div>
    <ul class="product-list"style="margin-top:90px;">
        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-1.jpg" width="312" height="350" loading="lazy"
                        alt="Running Sneaker Shoes" class="image-contain">
                        

                    <div class="card-badge">New</div>
                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelled by="card-label-1" onclick="addToCart( 'product-1.jpg','Running Sneaker shoes ','₹ 980.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Women</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Running Sneaker Shoes</a>
                    </h3>

                    <data class="card-price" value="1180.85">₹1180.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-2.jpg" width="312" height="350" loading="lazy"
                        alt="Leather Mens Slipper" class="image-contain">

                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelled by="card-label-1" onclick="addToCart('product-2.jpg','Leather Mens shoes','₹ 1190.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Sports</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Leather Mens Slipper</a>
                    </h3>

                    <data class="card-price" value="1090.85">₹1090.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-3.jpg" width="312" height="350" loading="lazy"
                        alt="Simple Fabric Shoe" class="image-contain">

                    <div class="card-badge">New</div>
                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-3.jpg','Simple Fabric shoes','₹ 1060.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                      
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Women</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Simple Fabric Shoe</a>
                    </h3>

                    <data class="card-price" value="1160.85">₹1160.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-4.jpg" width="312" height="350" loading="lazy"
                        alt="Air Jordan 7 Retro" class="image-contain">

                    <div class="card-badge">-25%</div>
                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-4.jpg','Air Jordan 7 Retro','₹ 1170.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       
                    </ul>
                </figure>
                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> 
                        <a href="collection.php" class="card-cat-link">Sports</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Air Jordan 7 Retro</a>
                    </h3>

                    <data class="card-price" value="870.85">₹870.85 <del>₹1200.21</del></data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-5.jpg" width="312" height="350" loading="lazy"
                        alt="Nike Air Max 270 SE" class="image-contain">

                    <div class="card-badge">New</div>
                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-5.jpg','Nike Air Max 270 SE','₹ 1200.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       
                       
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Women</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Nike Air Max 270 SE</a>
                    </h3>

                    <data class="card-price" value="920.85">₹920.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-6.jpg" width="312" height="350" loading="lazy"
                        alt="Adidas Sneakers Shoes" class="image-contain">

                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-6.jpg','Adidas Sneaker shoes','₹ 1080.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       

                       
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Women</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Adidas Sneakers Shoes</a>
                    </h3>

                    <data class="card-price" value="1000.85">₹1000.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-7.jpg" width="312" height="350" loading="lazy"
                        alt="Nike Basketball shoes" class="image-contain">

                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-7.jpg','Nike Basketball shoes','₹ 1200.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       

                        
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Sports</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Nike Basketball shoes</a>
                    </h3>

                    <data class="card-price" value="830.85">₹830.85</data>
                </div>
            </div>
        </li>

        <li class="product-item">
            <div class="product-card" tabindex="0">
                <figure class="card-banner">
                    <img src="./img/product-8.jpg" width="312" height="350" loading="lazy"
                        alt="Simple Fabric Shoe" class="image-contain">

                    <ul class="card-action-list">
                        <li class="card-action-item">
                            <button class="card-action-btn" aria-labelledby="card-label-1" onclick="addToCart('product-8.jpg','Simple Fabric shoes','₹ 1000.85')">
                                <i class="bx bx-cart-alt"></i>
                            </button>

                            <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                        </li>

                       

                       
                    </ul>
                </figure>

                <div class="card-content">
                    <div class="card-cat">
                        <a href="collection.php" class="card-cat-link">Men</a> /
                        <a href="collection.php" class="card-cat-link">Women</a>
                    </div>

                    <h3 class="h3 card-title">
                        <a href="#">Simple Fabric Shoe</a>
                    </h3>

                    <data class="card-price" value="1000.85">₹1000.85</data>
                </div>
            </div>
        </li>

    </ul>
</div>
</section>
<script>
    function addToCart(imageUrl, itemName, discount) {
   // Check if the item already exists in the cart
   var existingCartItem = document.querySelector(`.cart-item img[src="./img/${imageUrl}"]`);
   
   if (existingCartItem) {
     // If the item exists, increase its quantity
     var quantityElement = existingCartItem.parentNode.querySelector('.quantity');
     var quantity = parseInt(quantityElement.textContent) + 1;
     quantityElement.textContent = quantity;
   } else {
     // If the item does not exist, create a new cart item
     var cartItem = document.createElement('div');
     cartItem.classList.add('cart-item');
     cartItem.innerHTML = `
       <img src="./img/${imageUrl}" alt="${itemName}">
       <span>${itemName}</span>
       <span class="quantity">1</span>
       <span>${discount}</span>
       <button class="remove-btn" onclick="removeFromCart(this)" aria-label="remove item">Remove</button>
     `;
     document.getElementById('cart').appendChild(cartItem);
   }
 }
 
 function removeFromCart(button) {
   var itemToRemove = button.parentNode;
   itemToRemove.parentNode.removeChild(itemToRemove);
 }
 
   </script>
<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
</html>