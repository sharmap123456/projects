
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>collection</title>
    <link rel="stylesheet" href="boxicons-2.1.2/css/boxicons.css">
    <link rel="stylesheet" href="boxicons-2.1.2/css/boxicons.min.css">
    <link rel="stylesheet" href="boxicons-2.1.2/css/style.css">
    <link rel="shortcut icon" href="./favicon.svg" type="image/x-icon">

</head>
<header class="header" data-header>
    <div class="container">
        <div class="overlay" data-overlay></div>
        <a href="index.php" class="logo">
            <img src="img/Fitbit-removebg-preview.png" width="auto" height="150" alt="Fitbit Logo">
        </a>

        <button class="nav-open-btn" data-nav-open-btn aria-label="Open Menu">
            <i class="bx bx-menu"></i>
        </button>

        <nav class="navbar" data-navbar>
            <button class="nav-close-btn" data-nav-close-btn aria-label="Close Menu">
                <i class="bx bx-x"></i>
            </button>

            <a href="" class="logo">
                <img src="img/Fitbit-removebg-preview.png" width="190" height="250" alt="Fitbit Logo">
            </a>

            <ul class="navbar-list">
                <li class="navbar-item">
                    <a href="index.php" class="navbar-link">Home</a>
                </li>
                <li class="navbar-item">
                    <a href="collection.php" class="navbar-link">Collection</a>
                </li>
                <li class="navbar-item">
                    <a href="product.php" class="navbar-link">Products</a>
                </li>
                <li class="navbar-item">
                    <a href="shop.php" class="navbar-link">Shop</a>
                </li>
                <li class="navbar-item">
                    <a href="contact.php" class="navbar-link">Contact</a>
                </li>
            </ul>

            <ul class="nav-action-list">
               

                <li>
                    <a href="login.php" class="nav-action-btn">
                    <p class="navbar-link"> My Account</p>
                        <i class="bx bx-user" aria-hidden="true"></i>

                        <span class="nav-action-text">Login / Register</span>
                    </a>
                </li>

              
               
            </ul>
        </nav>
    </div>
</header>
<body>
    <section class="section collection">
        <div class="container">
            <ul class="banner">
                <li>
                    <div class="collection-banner" style="background-image: url('./img/1.jpg');">
                        <h2 class="hero-title" style="color: white;">Men's Collections</h2>

                        <a href="product.php" class="btn btn-primary " >

                            <span>Explore All</span>
                            <i class="bx bx-right-arrow-alt" aria-hidden="true"></i>
                        </a>
                    </div>
                </li>
                
                <li>
                    <div class="collection-banner" style="background-image: url('./img/p.jpg');">
                        <h2 class="hero-title" style="color: white;">Women's Collections</h2>

                        <a href="product.php" class="btn btn-primary " >

                            <span>Explore All</span>
                            <i class="bx bx-right-arrow-alt" aria-hidden="true"></i>
                        </a>
                    </div>
                </li>
                
                <li>
                    <div class="collection-banner" style="background-image: url('./img/close-up-futuristic-sneakers_23-2151005647.jpg');">
                        <h2 class="hero-title" style="color: white;">Sports's Collections</h2>

                        <a href="product.php" class="btn btn-primary " >

                            <span>Explore All</span>
                            <i class="bx bx-right-arrow-alt" aria-hidden="true"></i>
                        </a>
                    </div>
                </li>
                
            </ul>
        </div>
    </section>
</body>
</html>